#include "MyForm.h"
using namespace finalproject;
int main()
{
	MyForm cal;
	cal.ShowDialog();
}
